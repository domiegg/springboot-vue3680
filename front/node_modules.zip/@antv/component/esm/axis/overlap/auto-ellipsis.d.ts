import { IGroup } from '@antv/g-base';
export declare function getDefault(): typeof ellipsisTail;
export declare function ellipsisHead(isVertical: boolean, labelGroup: IGroup, limitLength: number): boolean;
export declare function ellipsisTail(isVertical: boolean, labelGroup: IGroup, limitLength: number): boolean;
export declare function ellipsisMiddle(isVertical: boolean, labelGroup: IGroup, limitLength: number): boolean;
