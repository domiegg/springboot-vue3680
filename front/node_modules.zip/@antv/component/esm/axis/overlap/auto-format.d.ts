import { IGroup } from '@antv/g-base';
export declare function formatLabels(labelGroup: IGroup, limitLength: number, unit: number, suffix: string): boolean;
