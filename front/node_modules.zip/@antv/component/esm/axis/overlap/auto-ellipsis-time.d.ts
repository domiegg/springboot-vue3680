import { IGroup } from '@antv/g-base';
export declare function ellipsisTime(labelGroup: IGroup, limitLength: number): boolean;
