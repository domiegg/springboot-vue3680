import { Point } from '../types';
import GridBase from './base';
declare class Line extends GridBase {
    getDefaultCfg(): {
        type: string;
        name: string;
        line: {};
        alternateColor: any;
        capture: boolean;
        items: any[];
        closed: boolean;
        defaultCfg: {
            line: {
                type: string;
                style: {
                    lineWidth: number;
                    stroke: string;
                };
            };
        };
        container: any;
        shapesMap: {};
        group: any;
        isRegister: boolean;
        isUpdating: boolean;
        isInit: boolean;
        id: string;
        locationType: string;
        offsetX: number;
        offsetY: number;
        animate: boolean;
        updateAutoRender: boolean;
        animateOption: {
            appear: any;
            update: {
                duration: number;
                easing: string;
            };
            enter: {
                duration: number;
                easing: string;
            };
            leave: {
                duration: number;
                easing: string;
            };
        };
        events: any;
        visible: boolean;
    };
    protected getGridPath(points: Point[]): any[];
}
export default Line;
