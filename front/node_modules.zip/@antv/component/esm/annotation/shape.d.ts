import { IGroup } from '@antv/g-base';
import GroupComponent from '../abstract/group-component';
import { ShapeAnnotationCfg } from '../types';
export default class ShapeAnnotation extends GroupComponent<ShapeAnnotationCfg> {
    getDefaultCfg(): {
        name: string;
        type: string;
        draw: () => void;
        container: any;
        shapesMap: {};
        group: any;
        capture: boolean;
        isRegister: boolean;
        isUpdating: boolean;
        isInit: boolean;
        id: string;
        locationType: string;
        offsetX: number;
        offsetY: number;
        animate: boolean;
        updateAutoRender: boolean;
        animateOption: {
            appear: any;
            update: {
                duration: number;
                easing: string;
            };
            enter: {
                duration: number;
                easing: string;
            };
            leave: {
                duration: number;
                easing: string;
            };
        };
        events: any;
        defaultCfg: {};
        visible: boolean;
    };
    protected renderInner(group: IGroup): void;
}
