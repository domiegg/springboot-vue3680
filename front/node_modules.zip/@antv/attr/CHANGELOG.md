## 0.3.1 (2020-01-10)

- 使用 @antv/color-util
- 测试框架迁移至 jest-electron
