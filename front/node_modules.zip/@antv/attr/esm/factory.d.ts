import Attribute, { AttributeConstructor } from './attributes/base';
/**
 * 通过类型获得 Attribute 类
 * @param type
 */
declare const getAttribute: (type: string) => any;
declare const registerAttribute: (type: string, ctor: AttributeConstructor) => void;
export { getAttribute, registerAttribute, Attribute };
export * from './interface';
