import { AttributeCfg } from '../interface';
import Attribute from './base';
export default class Color extends Attribute {
    gradient: (percent: number) => string;
    constructor(cfg: AttributeCfg);
    /**
     * @override
     */
    getLinearValue(percent: number): string;
}
