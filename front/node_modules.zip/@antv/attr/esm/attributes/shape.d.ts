import { AttributeCfg } from '../interface';
import Attribute from './base';
export default class Shape extends Attribute {
    constructor(cfg: AttributeCfg);
    /**
     * @override
     */
    getLinearValue(percent: number): string;
}
