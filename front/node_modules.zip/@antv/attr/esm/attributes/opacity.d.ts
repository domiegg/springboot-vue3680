import { AttributeCfg } from '../interface';
import Attribute from './base';
export default class Opacity extends Attribute {
    constructor(cfg: AttributeCfg);
}
