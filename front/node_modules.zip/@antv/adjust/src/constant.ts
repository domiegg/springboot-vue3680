export const DEFAULT_Y = 0; // 默认的 y 的值

// 偏移之后，间距
export const MARGIN_RATIO = 1 / 2;
export const DODGE_RATIO = 1 / 2;

// 散点分开之后，距离边界的距离
export const GAP = 0.05;
