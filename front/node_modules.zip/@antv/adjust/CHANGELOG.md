#### 0.2.5 (2022-01-23)

##### New Features

- fix(g2-issue-3737): 允许外部传入 dimValuesMap，替代从数据中获取([9f1b441](https://github.com/antvis/adjust/commit/9f1b441c69e66816431c7194a339abeb21fba40b))

#### 0.1.1 (2019-02-11)

##### Bug Fixes

- 修复只有一组数据时基础 dodge 算法偏差问题 ([9464cd75](https://github.com/antvis/adjust/commit/9464cd75d54e23cc94a5e022f531ffb6ac6d382b))

#### 0.0.1 (2018-06-25)

init.
