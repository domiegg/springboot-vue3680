import Adjust, { AdjustConstructor } from './adjusts/adjust';
/**
 * 根据类型获取 Adjust 类
 * @param type
 */
declare const getAdjust: (type: string) => AdjustConstructor;
/**
 * 注册自定义 Adjust
 * @param type
 * @param ctor
 */
declare const registerAdjust: (type: string, ctor: AdjustConstructor) => void;
export { getAdjust, registerAdjust, Adjust };
export * from './interface';
