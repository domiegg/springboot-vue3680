export declare const DEFAULT_Y = 0;
export declare const MARGIN_RATIO: number;
export declare const DODGE_RATIO: number;
export declare const GAP = 0.05;
